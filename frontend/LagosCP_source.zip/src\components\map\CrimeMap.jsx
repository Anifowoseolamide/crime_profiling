import { useEffect, useRef } from 'react';
import { MapContainer, TileLayer, CircleMarker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import { subjects } from '../../data/mockData';

const hotspots = [
  { lat: 6.5540, lng: 3.3444, name: 'Oshodi', severity: 'HIGH', count: 14 },
  { lat: 6.6186, lng: 3.3215, name: 'Agege', severity: 'MEDIUM', count: 8 },
  { lat: 6.4475, lng: 3.4735, name: 'Lekki', severity: 'LOW', count: 3 },
  { lat: 6.5244, lng: 3.3792, name: 'Mushin', severity: 'HIGH', count: 11 },
  { lat: 6.5244, lng: 3.3792, name: 'Surulere', severity: 'MEDIUM', count: 6 },
];

const severityColor = { HIGH: '#FF3B3B', MEDIUM: '#F59E0B', LOW: '#3B82F6' };

export default function CrimeMap({ height = '300px', showAllLayers = false }) {
  return (
    <div style={{ height }} className="rounded-xl overflow-hidden border border-border-color-light dark:border-border-color">
      <MapContainer
        center={[6.5244, 3.3792]}
        zoom={12}
        style={{ height: '100%', width: '100%' }}
        scrollWheelZoom={showAllLayers}
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />

        {/* Crime Hotspots */}
        {hotspots.map((h, i) => (
          <CircleMarker
            key={`hotspot-${i}`}
            center={[h.lat, h.lng]}
            radius={h.count}
            pathOptions={{
              color: severityColor[h.severity],
              fillColor: severityColor[h.severity],
              fillOpacity: 0.3,
              weight: 2
            }}
          >
            <Popup>
              <div className="text-xs font-mono">
                <div className="font-bold">{h.name}</div>
                <div>Severity: {h.severity}</div>
                <div>Incidents: {h.count}</div>
              </div>
            </Popup>
          </CircleMarker>
        ))}

        {/* Wanted subjects */}
        {subjects.filter(s => s.status === 'WANTED').map((s, i) => (
          <CircleMarker
            key={`wanted-${i}`}
            center={[s.coordinates.lat, s.coordinates.lng]}
            radius={8}
            pathOptions={{ color: '#FF3B3B', fillColor: '#FF3B3B', fillOpacity: 0.8 }}
          >
            <Popup>
              <div className="text-xs font-mono">
                <div className="font-bold text-red-600">{s.name}</div>
                <div>⚠ WANTED</div>
              </div>
            </Popup>
          </CircleMarker>
        ))}
      </MapContainer>
    </div>
  );
}
