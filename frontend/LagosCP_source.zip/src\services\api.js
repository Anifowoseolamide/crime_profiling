import { userProfiles, subjects, auditLogs } from '../data/mockData';

// Simulated delay helper
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

export const api = {
  // POST /api/auth/login/
  login: async (badgeId, password) => {
    await delay(800); // Simulate network latency
    const user = userProfiles.find(u => u.badgeId === badgeId && u.password === password);
    if (!user) {
      throw new Error("Invalid badge number or password. Check credentials.");
    }
    // Simulate JWT token return
    return {
      token: `mock-jwt-token.${btoa(JSON.stringify({ bg: user.badgeId, role: user.role }))}.signature`,
      user: user
    };
  },

  // POST /api/identify/
  identifyFace: async (base64Image, location, coords) => {
    await delay(2500); // Simulate AI processing time
    
    // For our mock, we'll randomize the result, but keep it deterministic based on time
    // Roughly 30% chance wanted, 30% chance clear, 40% no match
    const rand = Math.random();
    if (rand < 0.3) {
      return { match: true, subject: subjects[0] }; // Kingsley (Wanted)
    } else if (rand < 0.6) {
      return { match: true, subject: subjects[2] }; // Chioma (Cleared)
    } else {
      return { match: false, subject: null }; // No match
    }
  },

  // GET /api/subjects/:id/
  getSubject: async (id) => {
    await delay(400);
    const subject = subjects.find(s => s.id === id);
    if (!subject) throw new Error("Subject not found");
    return subject;
  },

  // GET /api/subjects/
  searchSubjects: async (queryStr = "", statusFilter = "ALL") => {
    await delay(600);
    let results = subjects;
    
    if (queryStr) {
      const q = queryStr.toLowerCase();
      results = results.filter(s => 
        s.name.toLowerCase().includes(q) || 
        s.id.toLowerCase().includes(q) ||
        s.aliases.some(a => a.toLowerCase().includes(q))
      );
    }
    
    if (statusFilter !== "ALL") {
      results = results.filter(s => s.status === statusFilter);
    }
    
    return results;
  },

  // GET /api/wanted/
  getWantedList: async () => {
    await delay(500);
    return subjects.filter(s => s.status === "WANTED");
  },

  // GET /api/audit/
  getAuditLog: async () => {
    await delay(300);
    return auditLogs;
  },
  
  // POST /api/offences/
  logOffence: async (data) => {
    await delay(1200);
    return { success: true, offenceCode: `OFF-NEW-${Math.floor(Math.random() * 1000)}` };
  }
};
